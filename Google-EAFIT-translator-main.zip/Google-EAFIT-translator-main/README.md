# Google-EAFIT-Translator

Software for voice2voice translate system without machine lerning via sockets

(now in process)